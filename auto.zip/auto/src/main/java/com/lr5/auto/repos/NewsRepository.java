package com.lr5.auto.repos;
import com.lr5.auto.entity.News;
import org.springframework.data.repository.CrudRepository;

public interface NewsRepository extends CrudRepository<News, Long> { }